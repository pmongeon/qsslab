---
title: "Breaking the silos: Collaboration between practitioners and academics in the Canadian LIS community"
 
event: BRIC2023
event_url:
  
authors:
  - Philippe Mongeon
tags:

url_slides: 'slides.html'
 
 
# Talk start and end times.
date: '2023-06-07T9:00:00Z'
date_end: '2023-06-07T10:00:00Z'
all_day: false
 
# Do not modify this next line.
publishDate: '2022-06-15T00:00:00Z'
 
---
